﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace Geometry
{
    class Program
    {
        interface IReflectable
        {
            void ReflectX();
            void ReflectY();
        }

        class Point
        {
            private decimal x;
            private decimal y;

            public Point(decimal X)
            {
                x = X;
                y = 0.0m;
            }

            public Point(decimal X, decimal Y)
            {
                x = X;
                y = Y;
            }

            public void ReflectX()
            {
                x = -x;
            }

            public void ReflectY()
            {
                y = -y;
            }
        }
        static void Main(string[] args)
        {
            var point11 = new Point(3.4m);
            var point22 = new Point(4.1m, 3.4m);
        }
    }
}
